declare const worlds: Partial<Record<string, { address: `0x${string}`; blockNumber?: number }>>;
export default worlds;
